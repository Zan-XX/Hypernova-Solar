.. _serial:

CAN over Serial
===============


Bus
---

.. autoclass:: can.interfaces.serial_can.Bus


Internals
---------

#TODO: Implement and document serial interface.
